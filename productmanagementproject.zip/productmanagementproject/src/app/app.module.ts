import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {HttpClientModule} from '@angular/common/http'
import { AppRoutingModule } from './app-routing.module';
import { Router, Routes } from '@angular/router';
import {  } from '@angular/router';
import { AppComponent } from './app.component';
import { ProductListComponent } from './component/product-list/product-list.component';
import { ProductcategoryListComponent } from './component/productcategory-list/productcategory-list.component';
import { WelcomeComponent } from './component/welcome/welcome.component';


const route : Routes =[
  {path: '',component:WelcomeComponent},
  {path: 'product',component:ProductListComponent},
  {path: 'productcategory',component:ProductcategoryListComponent}
]
@NgModule({
  declarations: [
    AppComponent,
    ProductListComponent,
    ProductcategoryListComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
