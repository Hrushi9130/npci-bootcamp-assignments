import { Component, OnInit } from '@angular/core';
import { Productcategory } from 'src/app/common/productcategory';
import { ManagementServiceService } from 'src/app/services/management-service.service';

@Component({
  selector: 'app-productcategory-list',
  templateUrl: './productcategory-list.component.html',
  styleUrls: ['./productcategory-list.component.css']
})
export class ProductcategoryListComponent implements OnInit {
  productcat : Productcategory[] 

  constructor(private service: ManagementServiceService) { }

  ngOnInit(): void {
    this.listOfProductcategory()
  }

  listOfProductcategory(){
    this.service.getAllProductCategory().subscribe(data=>{

      console.log(data);
      this.productcat=data;


    })

}
}


