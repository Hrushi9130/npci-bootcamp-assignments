import { Component, OnInit } from '@angular/core';
import { Product } from 'src/app/common/product';
import { ManagementServiceService } from 'src/app/services/management-service.service';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {
  
  product : Product[] 

  constructor(private service: ManagementServiceService) { }
  formModel : Product = new Product(0,"","",0,0,"","",0,);

  ngOnInit(): void {

    this.listOfProducts()
  }

  listOfProducts(){
    this.service.getAllProducts().subscribe(data=>{

      console.log(data);
     
      this.product=data;


    })

}

onSubmit(){
  this.product.push(this.formModel);
}
}
