export class Product {

    constructor(public id:number,
        public name:string,
        public description:string,
        public unitPrice: number,
        public unitInStock:number,
        public dateCreated:Date,
        public lastUpdated:Date,
        public categoryId:number){}
}
