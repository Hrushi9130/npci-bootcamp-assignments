package com.product.productmanagement.repository;

import java.util.List;


import com.product.productmanagement.entity.Product;

public interface ProductRepository {
	
	public List<Product> findAll();
	
	public Product findById(long id);
	
	public void save(Product p);
	
	

}
