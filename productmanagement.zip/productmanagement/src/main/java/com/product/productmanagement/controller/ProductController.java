package com.product.productmanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.product.productmanagement.entity.Product;
import com.product.productmanagement.service.ProductService;

@RestController
@RequestMapping("/product")
public class ProductController {
	
	@Autowired
	private ProductService service;
	
	@GetMapping("/productList")
	public List<Product> findAll(){
		return service.findAll();
	}
	
	@GetMapping("/products/{productId}")
	public Product findById(@PathVariable long productId) {
		
		Product p = service.findById(productId);
		
		if(p == null)
			throw new RuntimeException("Product Id: "+productId +"Details not found" );
		return p;
		
	}
	
	@PostMapping("/products")
	public Product save(@RequestBody Product p) {
		p.setId(0);
		service.saveOrUpdate(p);
		return p;
	}
	
	@PutMapping("/updateProduct")
	public String updateProduct(@RequestBody Product p) throws Exception {
	
		
		service.saveOrUpdate(p);
		
		return "Category ID : "+ p.getCategoryId() + " Details updated Succesfully !!"; 
	}

	@DeleteMapping("product/{id}")
	public String deleteById(@PathVariable long id) {
		service.deleteById(id);
		return "Product ID : " + id +"details  deleted !!!";
	}
	

	
	

}
