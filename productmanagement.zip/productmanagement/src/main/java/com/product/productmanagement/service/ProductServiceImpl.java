package com.product.productmanagement.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.product.productmanagement.entity.Product;
import com.product.productmanagement.repository.ProductRepository;

@Service
public class ProductServiceImpl implements ProductService{

	@Autowired
	private ProductRepository repository;
	
	public List<Product> findAll() {
		// TODO Auto-generated method stub
		return repository.findAll();
	}


	public Product findById(long id) {
		// TODO Auto-generated method stub
		return repository.findById(id);
	}


	@Transactional
	public void save(Product p) {
		// TODO Auto-generated method stub
		
		
		
	}


	@Transactional
	public void saveOrUpdate(Product p) {
		// TODO Auto-generated method stub
		repository.saveOrUpdate(p);
		
		
	}


	@Transactional
	public void deleteById(long id) {
		// TODO Auto-generated method stub
		
		repository.deleteById(id);
		
	}

}
