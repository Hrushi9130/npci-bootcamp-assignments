package com.product.productmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class productmanagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
