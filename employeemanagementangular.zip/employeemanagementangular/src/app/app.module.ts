import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { Router,  Routes } from '@angular/router';
import { FormsModule } from '@angular/forms';
import {HttpClientModule} from '@angular/common/http'
import { AppComponent } from './app.component';
import { EmpListComponent } from './component/emp-list/emp-list.component';
import { DeptListComponent } from './component/dept-list/dept-list.component';
import { WelcomeComponent } from './component/welcome/welcome.component';

const route : Routes =[
  {path: '',component:WelcomeComponent},
  {path: 'employee',component:EmpListComponent},
  {path: 'department',component:DeptListComponent}
]
@NgModule({
  declarations: [
    AppComponent,
    EmpListComponent,
    DeptListComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule
   
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
