export class Department {

    constructor(public deptNo:number,
        public deptName:string,
        public loc:string
        ){}
}
