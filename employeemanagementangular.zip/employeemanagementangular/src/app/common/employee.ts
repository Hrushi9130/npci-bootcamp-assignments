export class Employee {

    constructor(public empNo:number,
                public empName:string,
                public job:string,
                public hireDate:Date,
                public managerId: number,
                public salary:number,
                public commission:number,
                public deptNo:number){}
}
