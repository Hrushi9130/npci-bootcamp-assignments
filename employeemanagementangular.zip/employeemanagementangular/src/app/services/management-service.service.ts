import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
import { Department } from '../common/department';
import { Employee } from '../common/employee';

@Injectable({
  providedIn: 'root'
})
export class ManagementServiceService {

  empUrl= "http://localhost:8080/api/emp"
  deptUrl="http://localhost:8080/api/dept"


  constructor(private httpClient:HttpClient) { }

  getAllEmployees() : Observable<Employee[]>{
    return this.httpClient.get<GetResponseEmployee>(this.empUrl).pipe(map(response => response._embedded.employees))
  }

  getAllDepartment() : Observable<Department[]>{
    return this.httpClient.get<GetResponseDepartment>(this.deptUrl).pipe(map(response => response._embedded.department))
  }

}

interface GetResponseEmployee{
  _embedded:{
    employees:Employee[]
  }
}

interface GetResponseDepartment{
  _embedded:{
    department:Department[]
  }
}
