import { Component, OnInit } from '@angular/core';
import { Salesperson } from '../salesperson';

@Component({
  selector: 'app-sale-person-list',
  templateUrl: './sale-person-list.component.html',
  styleUrls: ['./sale-person-list.component.css']
})
export class SalePersonListComponent implements OnInit {

  s1 : Salesperson = new Salesperson("Hrushi","Ingle","hrushi@gmail.com",40000,"300");

  salesPersonList : Salesperson[] = [this.s1,
                           new Salesperson("samir","Ingle","samir@gmail.com",30000,"200"),
                           new Salesperson("mayur","rinde","mayur@gmail.com",15999,"100"),
                           new Salesperson("gopal","rinde","gopal@gmail.com",22000,"220")]

  
  constructor() { }
  formModel : Salesperson = new Salesperson("","","",0,"");
  ngOnInit(): void {

    console.log(this.formModel)
    
    
  }

  onSubmit(){
    this.salesPersonList.push(this.formModel);
  }
}
