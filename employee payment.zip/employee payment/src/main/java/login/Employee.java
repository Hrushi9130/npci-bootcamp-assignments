package login;

import java.util.Date;

public class Employee {
	//emp_name,e.emp_no,p.currentmonth,p.perdaysalry,p.monthdays
	 
	 private String eName;
	 private int empNo; 
	 private String  month; 
	 private int salary ;
	 private int hra;
	 float deduct;
	 
	public Employee(String eName, int empNo, String month, int salary, int day) {
		super();
		this.eName = eName;
		this.empNo = empNo;
		this.month = month;
		this.salary = salary * day;
	}
	public String geteName() {
		return eName;
	}
	public void seteName(String eName) {
		this.eName = eName;
	}
	public int getEmpNo() {
		return empNo;
	}
	public void setEmpNo(int empNo) {
		this.empNo = empNo;
	}
	public String getMonth() {
		return month;
	}
	public void setMonth(String month) {
		this.month = month;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public int getHra() {
		return hra;
	}
	public void setHra(int hra) {
		this.hra = hra;
	}
	public float getDeduct() {
		return deduct;
	}
	public void setDeduct(float deduct) {
		this.deduct = deduct;
	}
	@Override
	public String toString() {
		return "Employee [eName=" + eName + ", empNo=" + empNo + ", month=" + month + ", salary=" + salary + ", hra="
				+ hra + ", deduct=" + deduct + "]";
	}
	
	

}
