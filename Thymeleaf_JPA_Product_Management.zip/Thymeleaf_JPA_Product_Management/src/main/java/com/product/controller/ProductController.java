package com.product.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.product.entity.Product;
import com.product.service.ProductService;

@Controller
@RequestMapping("/product")
public class ProductController {
	
	@Autowired
	private ProductService service;
	
	@GetMapping("/proList")
	public String displayEmployees(Model model){
		List<Product> pro = service.findAll();
		model.addAttribute("PRODUCT",pro);
		
		return "productUI/product.html";
		
	}
	
	@GetMapping("/addProduct")
	public String empForm(Model model) {
		model.addAttribute("PRODUCT",new Product());
		return "productUI/productForm.html";
	}
	
	@PostMapping("/save")
	public String save(@ModelAttribute("PRODUCT") Product pro) {
		service.save(pro);
		
		return "redirect:/product/proList";
	}
	
	@GetMapping("/updateForm")
	public String updateForm(@RequestParam("proId") Long id, Model model) {
		Product pro = service.findById(id);
		model.addAttribute("PRODUCT",pro);
		return "productUI/productForm.html";
		
	}
	
	@GetMapping("/delete")
	public String deleteById(@RequestParam("proId") Long id) {
		service.deleteById(id);
		
		return "redirect:/product/proList";
	}

	
	

}
