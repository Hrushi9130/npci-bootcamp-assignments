package com.product.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.product.entity.Product;
import com.product.repository.ProductRepository;

@Service
public class ProductServiceImpl implements ProductService{
	
	@Autowired
	private ProductRepository repository;
	
	public List<Product> findAll() {
		// TODO Auto-generated method stub
		return repository.findAll();
	}

	
	public void save(Product p) {
		// TODO Auto-generated method stub
		
		repository.save(p);
		
	}

	
	public Product findById(Long id) {
		// TODO Auto-generated method stub
       Optional<Product> p =  repository.findById(id);
		
       Product pro = null;
		
		if(p.isPresent())
			pro = p.get();
		
		return pro;
	}

	
	public void deleteById(Long id) {
		// TODO Auto-generated method stub
		repository.deleteById(id);
	}

}
