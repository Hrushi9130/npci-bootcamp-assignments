export class Productcategory {

    constructor(
        public categoryId:number,
        public categoryName:string){}
}
