import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
import { Product } from '../common/product';
import { Productcategory } from '../common/productcategory';

@Injectable({
  providedIn: 'root'
})
export class ManagementserviceService {
  proUrl= "http://localhost:8080/api/pro"
  procatUrl="http://localhost:8080/api/proCat"

  constructor(private httpClient:HttpClient) { }

  getAllProducts() : Observable<Product[]>{
    return this.httpClient.get<GetResponseProduct>(this.proUrl).pipe(map(response => response._embedded.products))
  }

  getAllProductCategory() : Observable<Productcategory[]>{
    return this.httpClient.get<GetResponseProductcategory>(this.procatUrl).pipe(map(response => response._embedded.productCategories))
  }

  saveProduct(product : Product) : Observable<Product>{
    console.log(product)

    const httpOptions ={
      headers : new HttpHeaders({
        'Content-type' : 'application/json',
        'Authorization' : 'auth-token',
        'Access-Control-Allow-Origin' : '*'
      })
    };
    return this.httpClient.post<Product>(this.proUrl,product,httpOptions)
    
  }

  saveCategry(productcategory : Productcategory) : Observable<Productcategory>{
    console.log(productcategory)
    const httpOptions ={
      headers : new HttpHeaders({
        'Content-type' : 'application/json',
        'Authorization' : 'auth-token',
        'Access-Control-Allow-Origin' : '*'
      })
    };
    return this.httpClient.post<Productcategory>(this.procatUrl,productcategory,httpOptions)
    
  }
}

interface GetResponseProduct{
  _embedded:{
    products:Product[]
  }
}

interface GetResponseProductcategory{
  _embedded:{
    productCategories:Productcategory[]
  }
}
