import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {HttpClientModule} from '@angular/common/http'
import { Router, RouterModule, Routes } from '@angular/router';
import { AppComponent } from './app.component';
import { BuyerComponent } from './component/buyer/buyer.component';
import { MerchantComponent } from './component/merchant/merchant.component';
import { WelcomeComponent } from './component/welcome/welcome.component';
import { ProductFormComponent } from './component/product-form/product-form.component';
import { CategoryFormComponent } from './component/category-form/category-form.component';
import { ProductListComponent } from './component/product-list/product-list.component';
import { ProductcategoryListComponent } from './component/productcategory-list/productcategory-list.component';

import { FormsModule } from '@angular/forms';

const route : Routes =[
  {path: '',component:WelcomeComponent},
  {path: 'product',component:ProductListComponent},
  {path: 'productcategory',component:ProductcategoryListComponent},
  {path:'productForm',component:ProductFormComponent},
  {path:'productcategoryForm',component:CategoryFormComponent},
  {path:'buyer',component:BuyerComponent},
  {path:'merchant',component:MerchantComponent},
]
@NgModule({
  declarations: [
    AppComponent,
    BuyerComponent,
    MerchantComponent,
    WelcomeComponent,
    ProductFormComponent,
    CategoryFormComponent,
    ProductListComponent,
    ProductcategoryListComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    RouterModule.forRoot(route)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
