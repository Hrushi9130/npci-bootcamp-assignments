import { Component, OnInit } from '@angular/core';
import { Product } from 'src/app/common/product';
import { ManagementserviceService } from 'src/app/services/managementservice.service';

@Component({
  selector: 'app-buyer',
  templateUrl: './buyer.component.html',
  styleUrls: ['./buyer.component.css']
})
export class BuyerComponent implements OnInit {

  product : Product[] 
  constructor(private service : ManagementserviceService) { }

  ngOnInit(): void {
    this.listOfProduct()
  }

  listOfProduct(){
    this.service.getAllProducts().subscribe(data =>{
      this.product=data
    })
  }
 
}
