import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Productcategory } from 'src/app/common/productcategory';
import { ManagementserviceService } from 'src/app/services/managementservice.service';

@Component({
  selector: 'app-category-form',
  templateUrl: './category-form.component.html',
  styleUrls: ['./category-form.component.css']
})
export class CategoryFormComponent implements OnInit {
  productcat : Productcategory = new Productcategory(0,"");
  constructor(private service : ManagementserviceService ,private route:Router) { }

  ngOnInit(): void {
  }
  onSubmit(){
    this.service.saveCategry(this.productcat).subscribe(()=>{
      this.route.navigateByUrl("/productcategoryForm")
    })
  }

}
